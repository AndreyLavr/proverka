# stepic_web_project
For start -> 

	sudo /etc/init.d/nginx start
	ps -o pid,euser,egroup,comm,args -C nginx
	git clone https://github.com/kurotkin/stepic_web_project.git /home/box/web
	bash /home/box/web/init.sh
